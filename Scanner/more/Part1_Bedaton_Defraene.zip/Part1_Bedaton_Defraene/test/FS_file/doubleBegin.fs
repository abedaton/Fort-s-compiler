BEGINPROG
result := "the result of 5 + 3 = 4"
BEGINPROG
