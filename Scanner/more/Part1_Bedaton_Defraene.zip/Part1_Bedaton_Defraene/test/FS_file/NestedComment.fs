BEGINPROG NestedComment

/* this /* is a nested */ comment */

READ(number)
PRINT(number)

ENDPROG 
