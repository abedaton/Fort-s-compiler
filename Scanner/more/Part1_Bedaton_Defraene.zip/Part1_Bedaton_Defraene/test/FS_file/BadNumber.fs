BEGINPROG BadNumber

READ(number)

number := 012


ENDPROG
